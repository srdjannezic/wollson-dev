<?php return [
    'plugin' => [
        'name' => 'Widgets',
        'description' => ''
    ]
];